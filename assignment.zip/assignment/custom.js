const extension = ['txt','doc','docx','pdf'];
let output = document.getElementById('output');

function fileInfo(){
    let fileName = document.getElementById('file').files[0].name;
    let fileSize = document.getElementById('file').files[0].size;
	
	let fileExtension = fileName.split('.').pop();
    
    let file_info = fileName+"\n"+fileSize+"\n"+fileExtension;
	let flag = 0; 
	if(fileSize <= 5120){
		for(const ext of extension){
			if( fileExtension == ext){	
					let file = document.querySelector("#file").files[0];
					let reader = new FileReader();
					reader.addEventListener('load', function(e) {
							let text = e.target.result;
							const data = text;
						fileCheck(data);
					});
					reader.readAsText(file);				
				
				flag = 1;
				break;
			}	
		}
		if(flag==0){
			alert("File extension not allowed");
		}
	}
	else{
		alert("file is too big");
	}	
}

function fileCheck(file){
	let fileName = document.getElementById('file').files[0].name;
	
	let str_arr = file.split('\n');
	let noOfLines = str_arr.length;
	
	let noOfCharacters = file.length;
	
	let str_letter = file;
	let noOfLetters = str_letter.replace(/[^A-Z]/gi, "").length;
	
	let str_wordArr = file.split(' ');
	let noOfWords = str_wordArr.length;
	
	let oneLetter = 0;
	let twoLetter = 0;
	
	let spl_char = file;
	let noOfSplChar = spl_char.match(/[^A-Z]/gi).length;
	
	const words = file.split(" ");
	const lengths = words.map(function(word){
		return word.length;
	});
	let counter={};
	lengths.forEach((leng)=>{
		counter[leng]=counter[leng] || 0;
		counter[leng]++;
	});
	
	let data= 'File Name: ' + fileName+ '<br>Number of Lines: '+ noOfLines +'<br>Number of Characters (Total): '+ noOfCharacters +'<br>Number of Letters: '+ noOfLetters +'<br>Number of other characters: '+ noOfSplChar +'<br>Number of Words: '+ noOfWords +'<br>';
	
	output.innerHTML = data;
	
	for(const k in counter){
		if(counter.hasOwnProperty(k)){
			let data1 =  ("Number of "+k+ " letter words: "+counter[k] + "<br>");
			output.innerHTML = output.innerHTML + data1;
		}
	}
	
}